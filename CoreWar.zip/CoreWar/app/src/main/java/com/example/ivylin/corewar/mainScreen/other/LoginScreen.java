/* So far this java file has the same function with log-in screen.
 May add remember username or log out in the future*/
package com.example.ivylin.corewar.mainScreen.other;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.util.HashMap;

/**
 * Created by IvyLin on 20/01/2016.
 */
public class LoginScreen extends AppCompatActivity implements View.OnClickListener, AsyncResponse {

    private Button bLogin, bRegister;
    private EditText etUsername, etPassword;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        bLogin = (Button) findViewById(R.id.bLogin);
        bRegister = (Button) findViewById(R.id.bRegister);

        bLogin.setOnClickListener(this);
        bRegister.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bLogin:
                HashMap postData = new HashMap();
                String uName = etUsername.getText().toString();
                String uPassword = etPassword.getText().toString();

                if (uName != "" && uPassword != "") {
                    postData.put("uName", uName);
                    postData.put("uPassword", uPassword);
                    UserInformation.userName = uName;
                    PostResponseAsyncTask loginTask =
                            new PostResponseAsyncTask(this, postData, this);
                    //loginTask.execute("http://192.168.56.1/GRPtest/login.php");
                    loginTask.execute("http://192.168.43.34/login.php");  // this is for genymotion tese
                } else {
                    Toast.makeText(getApplicationContext(), "Please fill all the blanks", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.bRegister:
                startActivity(new Intent(this, RegisterScreen.class));
                finish();
                break;
        }
    }

    /**
     * Get the reply from php when operations on the server are finished
     *
     * @param output the string get back from the server
     */
    @Override
    public void processFinish(String output) {
        if (output.equals("success")) {
            Toast.makeText(this, "Login Successfully",
                    Toast.LENGTH_SHORT).show();
            UserInformation.userName = etUsername.getText().toString();
            intent = new Intent(getApplicationContext(), HomeScreen.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, output,
                    Toast.LENGTH_SHORT).show();
        }
    }
}
