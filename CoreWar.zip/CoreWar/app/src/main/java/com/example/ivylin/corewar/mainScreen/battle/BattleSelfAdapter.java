package com.example.ivylin.corewar.mainScreen.battle;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.example.ivylin.corewar.common.WarriorCardEntity;
import com.example.ivylin.corewar.mainScreen.SlotAdapter;

/**
 * Created by IvyLin on 07/04/2016.
 * Recycler view adapter
 */
public class BattleSelfAdapter extends RecyclerView.Adapter<BattleSelfAdapter.MyViewHolder> implements SlotAdapter {

    //private static HashMap<Integer,WarriorCardEntity> mdata = WarriorContainer.dataContainer;
    private LayoutInflater inflater;
    int[] selectedList;
    int counter;
    Context context;
    int added = 0;
    int cPos;


    public BattleSelfAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    /**
     * Initialize appearance of warrior slots for later*/
    public void setBack() {
        int id = cPos;
        WarriorCardEntity current = UserInformation.dataContainer.get(id);
        current.chosenFrame = 0;
        notifyItemChanged(id);
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        selectedList = new int[100];
        View view = inflater.inflate(R.layout.warrior_card, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        WarriorCardEntity current = UserInformation.dataContainer.get(position);
        if (UserInformation.empty == false) {
            holder.warriorImg.setImageResource(current.image);
            holder.warriorName.setText(current.title);
            holder.chosenFrame.setImageResource(current.chosenFrame);
        } else {
            holder.warriorImg.setImageResource(R.drawable.now);
            holder.warriorName.setText("");
        }
    }

    public void setAdded(int added) {
        this.added = added;
    }

    /**
     * This function is used for single Selection. Will see a pink
     * arrow when choosing p1, and it will change to blue when choosing p2
     * @param position the position of the current warrior file
     */
    public void singleSelected(int position) {
        cPos = position;
        WarriorCardEntity current = UserInformation.dataContainer.get(position);
        selectedList[counter] = position;
        if (counter == 0) {
            if (added == 1) {
                current.chosenFrame = R.drawable.arrow_blue;
                UserInformation.selectedBW[1] = current.title;
            } else {
                current.chosenFrame = R.drawable.arrow_pink;
                UserInformation.selectedBW[0] = current.title;

            }
        } else if (counter > 0) {
            WarriorCardEntity before = UserInformation.dataContainer.get(selectedList[counter - 1]);
            before.chosenFrame = 0;
            notifyItemChanged(selectedList[counter - 1]);

            if (added == 1) {
                current.chosenFrame = R.drawable.arrow_blue;
                UserInformation.selectedBW[1] = current.title;
            } else {
                current.chosenFrame = R.drawable.arrow_pink;
                UserInformation.selectedBW[0] = current.title;
            }
        }
        counter++;
        notifyItemChanged(position);
    }


    @Override
    public int getItemCount() {
        return UserInformation.dataContainer.size();
    }

    /**
     * This class is for the view holder for the adapter
     */
    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView warriorName;
        public ImageView warriorImg;
        public ImageView chosenFrame;

        public MyViewHolder(View itemView) {
            super(itemView);
            warriorImg = (ImageView) itemView.findViewById(R.id.listImg);
            warriorName = (TextView) itemView.findViewById(R.id.listText);
            chosenFrame = (ImageView) itemView.findViewById(R.id.listFrame);
            warriorImg.setOnClickListener(this);
        }


        /**
         * This class is called when the player short click on the warrior card
         * which means the warrior is selected
         */
        @Override
        public void onClick(View v) {
            singleSelected(getAdapterPosition());
        }


    }
}
