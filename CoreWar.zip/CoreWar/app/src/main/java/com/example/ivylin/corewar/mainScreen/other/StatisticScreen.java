package com.example.ivylin.corewar.mainScreen.other;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.example.ivylin.corewar.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by IvyLin on 26/01/2016.
 * Storing battle results
 */
public class StatisticScreen extends AppCompatActivity implements View.OnClickListener {

    Button bBack;
    TextView log;
    String corePath;
    String basePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistic);

        bBack = (Button) findViewById(R.id.bBack);
        log = (TextView) findViewById(R.id.log);
        bBack.setOnClickListener(this);
        Log.d("debug", "DOWNLOAD");
        corePath = this.getFilesDir() + "/CoreWar/" + "result.txt";
        basePath = this.getFilesDir() + "/CoreWar/";

        String content;
        FileReader filereader = null;
        try {
            filereader = new FileReader(corePath);
            BufferedReader bufferedReader = new BufferedReader(filereader);
            StringBuffer stringBuffer = new StringBuffer();
            while ((content = bufferedReader.readLine()) != null) {
                stringBuffer.append(content + "\n");
            }
            log.setText(stringBuffer.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        finish();
    }

}