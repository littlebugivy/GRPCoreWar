package com.example.ivylin.corewar.mainScreen.other;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.example.ivylin.corewar.common.WarriorCardContainer;
import com.example.ivylin.corewar.common.WarriorCardEntity;
import com.example.ivylin.corewar.mainScreen.battle.BattleScreen;
import com.example.ivylin.corewar.mainScreen.build.WarriorNormalSlotScreen;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

/**
 * Created by IvyLin on 18/01/2016.
 * Home screen
 */
public class HomeScreen extends AppCompatActivity implements View.OnClickListener, AsyncResponse {

    ImageButton userImg;
    Button bBattle, bWarrior, bInfo;
    TextView uName;
    HashMap postData = new HashMap();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bInfo = (Button) findViewById(R.id.bInfo);
        bBattle = (Button) findViewById(R.id.bBattle);
        userImg = (ImageButton) findViewById(R.id.userImg);
        bWarrior = (Button) findViewById(R.id.bWarriors);
        uName = (TextView) findViewById(R.id.userName);
        uName.setText(UserInformation.userName);

        iniAll();
        bInfo.setOnClickListener(this);
        bBattle.setOnClickListener(this);
        userImg.setOnClickListener(this);
        bWarrior.setOnClickListener(this);
    }

    /**
     * This method is used to create the user folder for every user,
     * get the warrior information of the warrior this user owns.
     */
    private void iniAll() {
        postData.put("userName", UserInformation.userName);
        PostResponseAsyncTask userFileCreateTask =
                new PostResponseAsyncTask(this, postData, this);
        userFileCreateTask.execute("http://192.168.43.34/create_user_folder.php");
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bBattle:
                startActivity(new Intent(this, BattleScreen.class));
                break;
            case R.id.bWarriors:
                startActivity(new Intent(this, WarriorNormalSlotScreen.class));
                break;
            case R.id.userImg:
                startActivity(new Intent(this, StatisticScreen.class));
                break;
            case R.id.bInfo:
                startActivity(new Intent(this, IntroductionScreen.class));
                break;
        }
    }


    @Override
    public void processFinish(String output) {
        /* Add all the user warrior to the warrior screen*/
        if (output != "") {
            UserInformation.empty = false;
            String wNameList[] = output.split(",");
            for (int i = 1; i < wNameList.length; i++) {
                WarriorCardEntity wEntity = new WarriorCardEntity();
                String temp[] = wNameList[i].split("#");
                wEntity.title = temp[0];
                wEntity.image = WarriorCardContainer.cards[Integer.parseInt(temp[1])];
                UserInformation.dataContainer.put(i - 1, wEntity);
                UserInformation.nameContainer.add(temp[0]);
                doDownload("http://192.168.43.34/warriorFiles/" + UserInformation.userName + "/" + wEntity.title + ".red", wEntity.title + ".red");
            }
        }
    }

    /**
     * Initialize the user infomation
     * download warrior information contains names, profile number and warrior code from the server
     *
     * @param urlLink  the link where information can be downloaded
     * @param fileName
     */

    protected void doDownload(final String urlLink, final String fileName) {
        Thread dx = new Thread() {

            public void run() {
                File root = android.os.Environment.getExternalStorageDirectory();
                File dir = new File(root.getAbsolutePath() + "/CoreWar/" + UserInformation.userName + "/");
                if (dir.exists() == false) {
                    dir.mkdirs();
                }
                //Save the path as a string value

                try {
                    URL url = new URL(urlLink);
                    Log.i("FILE_NAME", "File name is " + fileName);
                    Log.i("FILE_URLLINK", "File URL is " + url);
                    URLConnection connection = url.openConnection();
                    connection.connect();

                    // download the file
                    InputStream input = new BufferedInputStream(url.openStream());
                    OutputStream output = new FileOutputStream(dir + "/" + fileName);

                    byte data[] = new byte[1024];
                    long total = 0;
                    int count;
                    while ((count = input.read(data)) != -1) {
                        total += count;
                        output.write(data, 0, count);
                    }

                    output.flush();
                    output.close();
                    input.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        dx.start();
    }


}
