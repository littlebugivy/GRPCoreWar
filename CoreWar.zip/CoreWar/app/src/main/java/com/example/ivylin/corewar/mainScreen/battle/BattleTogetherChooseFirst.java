package com.example.ivylin.corewar.mainScreen.battle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;

/**
 * Created by IvyLin on 07/04/2016.
 * This class is for choosing first warrior in the muti-player mode
 */

public class BattleTogetherChooseFirst extends AppCompatActivity implements View.OnClickListener {
    Button bBack;
    Button bNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warrior_battle_together_first);
        bBack = (Button) findViewById(R.id.bBack);
        bNext = (Button) findViewById(R.id.bNext);

        bBack.setOnClickListener(this);
        bNext.setOnClickListener(this);
        UserInformation.cleanUpFrame();
        UserInformation.cleanUpSW();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bBack:
                finish();
                break;
            case R.id.bNext:
                Intent intent = new Intent(this, BattleTogetherChooseSecond.class);
                startActivity(intent);
                break;
        }
    }
}


