package com.example.ivylin.corewar.mainScreen.other;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.example.ivylin.corewar.R;

/**
 * Offer links related core war
 */
public class IntroductionScreen extends AppCompatActivity implements View.OnClickListener {
    private Button bStrategy, bCWUK, bFourm, bTournament;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        bStrategy = (Button) findViewById(R.id.bStrategy);
        bFourm = (Button) findViewById(R.id.bForum);
        bTournament = (Button) findViewById(R.id.bTournament);
        bCWUK = (Button) findViewById(R.id.bCWUK);

        bStrategy.setOnClickListener(this);
        bFourm.setOnClickListener(this);
        bTournament.setOnClickListener(this);
        bCWUK.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bStrategy:
                intent = new Intent(this, WebsiteScreen.class);
                intent.putExtra("url", "http://vyznev.net/corewar/guide.html#starting");
                startActivity(intent);
                finish();
                break;
            case R.id.bForum:
                intent = new Intent(this, WebsiteScreen.class);
                intent.putExtra("url", "http://corewar.eu/forum/");
                startActivity(intent);
                finish();
                break;
            case R.id.bTournament:
                intent = new Intent(this, WebsiteScreen.class);
                intent.putExtra("url", "http://sal.discontinuity.info/");
                startActivity(intent);
                finish();
                break;
            case R.id.bCWUK:
                intent = new Intent(this, WebsiteScreen.class);
                intent.putExtra("url", "http://corewar.co.uk/index.htm");
                startActivity(intent);
                finish();
                break;
        }
    }


}




