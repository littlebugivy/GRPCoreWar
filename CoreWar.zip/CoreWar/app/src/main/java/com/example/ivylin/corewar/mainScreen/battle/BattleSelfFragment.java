package com.example.ivylin.corewar.mainScreen.battle;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;

/**
 * Fragment used in the battle self screen, contains recycler view adapter
 */

public class BattleSelfFragment extends Fragment {
    private RecyclerView recyclerView;
    private BattleSelfAdapter adapter;

    EditText nP1;
    EditText nP2;
    Button bStart;
    static private int click;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        click = 0;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance) {
        View layout = inflater.inflate(R.layout.fragment_warrior_self_battle, container, false);
        recyclerView = (RecyclerView) layout.findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager;
        bStart = (Button) layout.findViewById(R.id.bOK);
        nP1 = (EditText) layout.findViewById(R.id.nP1);
        nP2 = (EditText) layout.findViewById(R.id.nP2);
        bStart.setText("P1 DONE");
        bStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (UserInformation.selectedBW[0].equals("")) {
                    Toast.makeText(getActivity().getApplicationContext(), "Please Choose A Warrior", Toast.LENGTH_SHORT).show();
                } else {

                    if (click == 0) {
                        nP1.setText(UserInformation.selectedBW[0]);
                        bStart.setText("P2 DONE");
                        adapter.setAdded(1);
                        click++;
                    } else if (click == 1 && !UserInformation.selectedBW[1].equals("")) {
                        nP2.setText(UserInformation.selectedBW[1]);
                        bStart.setText("BATTLE!");
                        click++;
                    }else if(click == 1 ){
                        Toast.makeText(getActivity().getApplicationContext(), "Please Choose A Warrior", Toast.LENGTH_SHORT).show();
                    }
                    else if (click == 2) {
                        ((BattleSelfScreen)getActivity()).loadBattleWarrior();
                        Toast.makeText(getActivity().getApplicationContext(), "You can view the battle on the PC now!", Toast.LENGTH_SHORT);
                        Intent intent = getActivity().getPackageManager().getLaunchIntentForPackage("x.org.server");
                        startActivity(intent);
                    }
                    adapter.setBack();
                }
            }
        });

        layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new BattleSelfAdapter(getActivity());
        recyclerView.setAdapter(adapter);
        return layout;
    }


}
