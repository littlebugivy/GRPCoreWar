package com.example.ivylin.corewar.common;

import com.example.ivylin.corewar.R;

/**
 * Created by IvyLin on 11/03/2016.
 * This class contains all the warrior images
 */
public class WarriorCardContainer {

   public static final int cards[] ={
           R.drawable.w1,
           R.drawable.w2,
           R.drawable.w3,
           R.drawable.w4,
           R.drawable.w5,
           R.drawable.w6,
           R.drawable.w7,
           R.drawable.w8,
           R.drawable.w9,
           R.drawable.w10,
           R.drawable.w11,
           R.drawable.w12,
           R.drawable.w13,
           R.drawable.w14,
           R.drawable.w15,
           R.drawable.w16,
           R.drawable.w17,
           R.drawable.w18,
           R.drawable.w19,
           R.drawable.w20,
           R.drawable.w21,
           R.drawable.w22,
           R.drawable.w23,
           R.drawable.w24,
           R.drawable.w25,
           R.drawable.w26,
           R.drawable.w27,
           R.drawable.w28,
           R.drawable.w29,
           R.drawable.w30,
   };
}
