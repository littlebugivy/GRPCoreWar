package com.example.ivylin.corewar.mainScreen.battle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.util.HashMap;

/**
 * Battle Screen Class, two mode can be chosen - self-play and play-together
 */
public class BattleScreen extends AppCompatActivity implements View.OnClickListener, AsyncResponse {
    private Button bSelf, bTogether;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle);

        bSelf = (Button) findViewById(R.id.bSelf);
        bTogether = (Button) findViewById(R.id.bTogether);
        bSelf.setOnClickListener(this);
        bTogether.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bSelf:
                UserInformation.battleMode = "SELF";
                startActivity(new Intent(this, BattleSelfScreen.class));
                break;
            case R.id.bTogether:
                getWarriorLibrary();
                startActivity(new Intent(this, BattleTogetherChooseFirst.class));
                break;
        }
    }

    /**
     * Get all the warriors which submitted by all the users from the server
     * Warrior names and warrior profiles are got for multiple player mode
     */
    public void getWarriorLibrary() {
        HashMap<String, String> postData = new HashMap<>();
        PostResponseAsyncTask warriorLibraryTask =
                new PostResponseAsyncTask(this, postData, this);
        warriorLibraryTask.execute("http://192.168.43.34/get_warrior_library.php");  // this is for genymotion tese
    }


    @Override
    public void processFinish(String output) {
        UserInformation.warriorLibrary = output;
    }

}
