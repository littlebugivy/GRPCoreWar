package com.example.ivylin.corewar.mainScreen.battle;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;

/**
 * Created by IvyLin on 07/04/2016.
 * Fragment for battle together
 */


public class BattleTogetherChooseFirstFragment extends Fragment {
    private RecyclerView recyclerView;
    private BattleTogetherChooseFirstAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance) {
        UserInformation.cleanUpFrame();
        View layout = inflater.inflate(R.layout.fragment_warriorr_normal_slot, container, false);
        recyclerView = (RecyclerView) layout.findViewById(R.id.recyclerview);
        adapter = new BattleTogetherChooseFirstAdapter(getActivity());
        recyclerView.setAdapter(adapter);
        LinearLayoutManager layoutManager;
        layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        return layout;
    }

}