package com.example.ivylin.corewar.mainScreen.battle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.example.ivylin.corewar.common.WarriorDownload;
import com.example.ivylin.corewar.mainScreen.other.HomeScreen;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.util.HashMap;

/**
 * Created by IvyLin on 05/02/2016.
 * Self-battle screen, two warriors are chosen and battle is started
 */

public class BattleSelfScreen extends AppCompatActivity implements View.OnClickListener, AsyncResponse {
    Button bBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warrior_battle_self_screen);
        bBack = (Button) findViewById(R.id.bBack);
        bBack.setOnClickListener(this);

        UserInformation.cleanUpFrame();
        UserInformation.cleanUpSW();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bBack:
                finish();
                break;
        }
    }

    /**
     * This class is used for loading battle warriors to the server for compiler execution
     */
    public void loadBattleWarrior() {
        HashMap<String, String> postData = new HashMap<>();
        postData.put("uName1", UserInformation.userName);
        postData.put("wName1", UserInformation.selectedBW[0] + ".red");
        postData.put("uName2", UserInformation.userName);
        postData.put("wName2", UserInformation.selectedBW[1] + ".red");
        PostResponseAsyncTask loginTask =
                new PostResponseAsyncTask(this, postData, this);
        loginTask.execute("http://192.168.43.34/load_battle_warrior.php");  // this is for genymotion tese
    }

    /**
     * Download the log file of the battle and go back to the home screen
     *
     * @param s string get back from the server
     */
    @Override
    public void processFinish(String s) {
        WarriorDownload warriorDownload = new WarriorDownload(this);
        warriorDownload.execute("http://192.168.43.34/result.txt");
        Toast.makeText(this, "Game Finished", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent();
        intent.setClass(this, HomeScreen.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}