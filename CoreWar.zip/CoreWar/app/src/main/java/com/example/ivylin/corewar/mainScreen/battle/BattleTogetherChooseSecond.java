package com.example.ivylin.corewar.mainScreen.battle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.example.ivylin.corewar.common.WarriorDownload;
import com.example.ivylin.corewar.mainScreen.other.HomeScreen;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.util.HashMap;

/**
 * Created by IvyLin on 07/04/2016.
 * Choose second battle warrior for multi-player mode
 */
public class BattleTogetherChooseSecond extends AppCompatActivity implements View.OnClickListener, View.OnTouchListener, AsyncResponse {
    Button bStart;
    TextView uName;
    TextView wName;
    BattleTogetherChooseSecondSV btSv;
    RelativeLayout wholeScreen;

    private boolean svStart = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warrior_battle_together_second);

        bStart = (Button) this.findViewById(R.id.bStart);
        uName = (TextView) this.findViewById(R.id.uName);
        wName = (TextView) this.findViewById(R.id.wName);
        wholeScreen = (RelativeLayout) this.findViewById(R.id.b_whole_screen);
        wholeScreen.setOnTouchListener(this);

        uName.setText("* Tap Screen *");     // * Tap Screen *
        wName.setText("Match Opponent...");   // Match Opponent...
        bStart.setVisibility(View.INVISIBLE);

        btSv = (BattleTogetherChooseSecondSV) this.findViewById(R.id.change_surfaceView);
        bStart.setOnClickListener(this);
        //bStop.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bStart:
                loadBattleWarrior(); // upload two warriors
                Toast.makeText(this, "Game Finished", Toast.LENGTH_SHORT);

                Intent intent = getPackageManager().getLaunchIntentForPackage("x.org.server");
                startActivity(intent);

                break;
        }
    }

    public void loadBattleWarrior() {
        HashMap<String, String> postData = new HashMap<>();
        postData.put("uName1", UserInformation.userName);
        postData.put("wName1", UserInformation.selectedBW[0] + ".red");
        postData.put("uName2", uName.getText().toString());
        postData.put("wName2", wName.getText().toString() + ".red");
        PostResponseAsyncTask loginTask =
                new PostResponseAsyncTask(this, postData, this);
        loginTask.execute("http://192.168.43.34/load_battle_warrior.php");  // this is for genymotion tese
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (svStart) {
                    String[] wInfo;
                    wInfo = btSv.stop().split(",");
                    uName.setText(wInfo[0]);  // set User Name
                    wName.setText(wInfo[1]);  // set Warrior Name
                    bStart.setVisibility(View.VISIBLE);
                    svStart = false;
                } else {
                    uName.setText("* Tab Screen *");
                    wName.setText("Match Opponent...");   // Match Opponent...
                    bStart.setVisibility(View.INVISIBLE);
                    btSv.start();
                    svStart = true;
                }
                break;
        }

        return false;
    }

    @Override
    public void processFinish(String output) {
        WarriorDownload warriorDownload = new WarriorDownload(this);
        warriorDownload.execute("http://192.168.43.34/result.txt");
        Log.d("Process", "PROCESS END");
        Intent intent = new Intent();
        intent.setClass(this, HomeScreen.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}