package com.example.ivylin.corewar.mainScreen;

/**
 * Created by IvyLin on 15/04/2016.
 * An interface for all the recycler adapters
 */
public interface SlotAdapter {
     void singleSelected(int position);
     void setBack();
}
