/*For register, click back go back to Login.java*/
package com.example.ivylin.corewar.mainScreen.other;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ivylin.corewar.R;
import com.example.ivylin.corewar.common.UserInformation;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;


import java.util.HashMap;

/**
 * Created by IvyLin on 24/01/2016.
 */
public class RegisterScreen extends AppCompatActivity implements View.OnClickListener, AsyncResponse {
    private Button bRegister, bBack;
    private EditText etUsername, etPassword, etRepeatpw;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etRepeatpw = (EditText) findViewById(R.id.etRepeatpw);
        bBack = (Button) findViewById(R.id.bBack);
        bRegister = (Button) findViewById(R.id.bRegister);

        bRegister.setOnClickListener(this);
        bBack.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bRegister:
                String uName = etUsername.getText().toString();
                String uPassword = etPassword.getText().toString();
                String uRepeatPassword = etRepeatpw.getText().toString();

                if (validatePassword(uPassword, uRepeatPassword) && validateUserName(uName)) {
                    HashMap postData = new HashMap();
                    postData.put("uName", uName);
                    postData.put("uPassword", uPassword);

                    PostResponseAsyncTask registerTask =
                            new PostResponseAsyncTask(this, postData, this);
                    //registerTask.execute("http://192.168.56.1/GRPtest/register.php");
                    registerTask.execute("http://192.168.43.34/register.php");

                }
                break;
            case R.id.bBack:
                startActivity(new Intent(this, LoginScreen.class));
                finish();
                break;
        }

    }

    /**
     * Validate password
     *
     * @param pw1 the password
     * @param pw2 the repeated password
     */
    private boolean validatePassword(String pw1, String pw2) {
        if (pw1.length() >= 3 && pw1.length() <= 20) {
            if (pw1.equals(pw2)) {
                return true;
            } else {
                Toast.makeText(this, "Passwords are not same",
                        Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        Toast.makeText(this, "Length of Password should be 3-20",
                Toast.LENGTH_SHORT).show();
        return false;
    }


    /**
     * Validate user name
     */
    private boolean validateUserName(String inputUsername) {
        if (inputUsername.length() >= 2 && inputUsername.length() <= 15) {
            return true;
        } else {
            Toast.makeText(this, "Length of Username should be 2-15",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    /**
     * Get the reply from php when operations on the server are finished
     *
     * @param output the string get back from the server
     */
    @Override
    public void processFinish(String output) {
        if (output.equals("success")) {
            Toast.makeText(this, "Register Successfully",
                    Toast.LENGTH_SHORT).show();
            UserInformation.userName = etUsername.getText().toString();
            intent = new Intent(getApplicationContext(), HomeScreen.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, output,
                    Toast.LENGTH_LONG).show();
        }
    }
}
