package com.example.ivylin.corewar.demoPlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

import com.example.ivylin.corewar.common.UserInformation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * Created by IvyLin on 01/04/2016.
 * An assistant class for demo display
 */

public class SurfaceViewDemoPlay extends SurfaceView implements Callback {

    LoopThread thread;
    int iniX = 35;
    int iniY = 60;
    int posX;
    int posY;
    int coreNumCounter = 0;
    String warrior1, warrior2;
    ArrayList<int[]> posRecord = new ArrayList<>();
    Iterator<int[]> posIterator;

    public SurfaceViewDemoPlay(Context context, String warrior1, String warrior2) {
        super(context);
        this.warrior1 = warrior1;
        this.warrior2 = warrior2;
        init();
    }

    public SurfaceViewDemoPlay(Context context, String warrior) {
        super(context);
        this.warrior1 = warrior;
        this.warrior2 = "";
        init();
    }

    private void init() {
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);
        thread = new LoopThread(holder, getContext());
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread.isRunning = true;
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        thread.isRunning = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void pause() {
        surfaceDestroyed(thread.surfaceHolder);
    }


    class LoopThread extends Thread {
        int screenWidth;
        int screenHeight;
        SurfaceHolder surfaceHolder;
        Context context;
        boolean isRunning;
        Paint paint;
        int eachLineNum;
        Canvas c = null;
        Random random;
        int counter = 0;
        int iniXRecord;
        int iniYRecord;

        public LoopThread(SurfaceHolder surfaceHolder, Context context) {
            random = new Random();
            int n = random.nextInt(24) + 1;  //25
            int m = random.nextInt(31) + 1;  //32

            posX = n * 70 - 35;  // initial to be 35
            posY = m * 30 + 30;  // initial to be 60
            iniXRecord = posX;
            iniYRecord = posY;
            this.screenHeight = UserInformation.screenHeight;
            this.screenWidth = UserInformation.screenWidth;
            this.surfaceHolder = surfaceHolder;
            this.context = context;
            eachLineNum = (screenWidth - 20) / 70;  // 70 = 50+20(50 is the length of the line, 20 is the)
            isRunning = false;
            paint = new Paint();
        }

        @Override
        public void run() {

            Log.d("TEST", String.valueOf(eachLineNum));

            while (isRunning) {
                doImpRun();
            }
        }

        public void doImpRun() {
            paint.setColor(Color.YELLOW);
            paint.setStyle(Paint.Style.FILL);
            try {
                Thread.sleep(50);
                posRecord.add(new int[]{posX, posY});
                doImpDraw();
                coreNumCounter++;
                counter++;
                if (posY == 990 && posX == 1715) {
                    posX = iniX;
                    posY = iniY;
                } else if (posX == 1715) {
                    posX = iniX;
                    posY = posY + 30;
                } else {
                    posX = posX + 70;
                }

                if (iniXRecord == posX && iniYRecord == posY) {
                    isRunning = false;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void doImpDraw() {
            posIterator = posRecord.iterator();
            Canvas c = surfaceHolder.lockCanvas();
            while (posIterator.hasNext()) {
                int[] temp = posIterator.next();
                c.drawRect(temp[0], temp[1], temp[0] + 50, temp[1] + 10, paint);
                Log.d("POSX", String.valueOf(temp[0]));
                Log.d("POSY", String.valueOf(temp[1]));
            }
            surfaceHolder.unlockCanvasAndPost(c);
        }
    }
}



