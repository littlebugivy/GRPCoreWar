package com.example.ivylin.corewar.demoPlay;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

import com.example.ivylin.corewar.common.UserInformation;

/**
 * Created by IvyLin on 02/04/2016.
 * This class contains the demo play
 */

public class DemoDisplay extends AppCompatActivity {
    SurfaceViewDemoPlay display;
    Intent intent;
    String w1Name="";
    String w2Name="";
    DisplayMetrics metric = new DisplayMetrics();

    protected void onCreate(Bundle savedInstanceState) {
        // set to full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        UserInformation.screenHeight = metric.heightPixels;
        UserInformation.screenWidth = metric.widthPixels;
        super.onCreate(savedInstanceState);
        intent = getIntent();
        this.w1Name = intent.getStringExtra("wName");
        display = new SurfaceViewDemoPlay(this,w1Name,w2Name);
        setContentView(display);
    }

    @Override
    protected void onPause() {
        super.onPause();
        display.pause();
    }
}
