package com.example.ivylin.corewar.mainScreen.battle;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.ivylin.corewar.common.UserInformation;
import com.example.ivylin.corewar.common.WarriorCardContainer;

import java.util.Random;

/**
 * Created by IvyLin on 14/04/2016.
 * Assistant class for choose second warrior for multi-player mode
 */
public class BattleTogetherChooseSecondSV extends SurfaceView implements SurfaceHolder.Callback {
    LoopThread thread;
    Context context;
    SurfaceHolder holder;
    String[] uNames = new String[100];
    String[] wNames = new String[100];
    String[] wImg = new String[100];
    int libSize = 0;
    int id = 0;

    public BattleTogetherChooseSecondSV(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
        this.context = context;
    }

    public BattleTogetherChooseSecondSV(Context context) {
        super(context);
        this.context = context;
        init();
    }

    /**
     * Initialize warrior cards state
     */
    private void init() {
        UserInformation.selectedBW[1] = "";
        SurfaceHolder holder = getHolder();
        this.holder = holder;
        holder.addCallback(this);
        thread = new LoopThread(holder, getContext());
        String wL[] = UserInformation.warriorLibrary.split(",");
        libSize = wL.length - 1;
        for (int i = 1; i < wL.length; i++) {
            String temp[] = wL[i].split("#");
            uNames[i - 1] = temp[0];
            wNames[i - 1] = temp[1];
            wImg[i - 1] = temp[2];
        }

    }

    /**
     * Stop the animation and display the warrior name and user name
     *
     * @return temp name of the chosen warrior
     */
    public String stop() {
        thread.isRunning = false;
        int index = id;
        String temp = uNames[index] + "," + wNames[index] + "," + wImg[index];
        return temp;
    }

    /**
     * Start the animation
     */
    public void start() {
        thread = new LoopThread(holder, getContext());
        thread.isRunning = true;
        surfaceCreated(holder);
    }


    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread.isRunning = true;
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        thread.isRunning = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Display animations showing all the warrior cards representing all the warrior files which are
     * submitted by all the users
     */

    class LoopThread extends Thread {
        SurfaceHolder surfaceHolder;
        Context context;
        boolean isRunning;
        Paint paint;
        Random random;

        public LoopThread(SurfaceHolder surfaceHolder, Context context) {
            this.surfaceHolder = surfaceHolder;
            this.context = context;
            isRunning = false;
            paint = new Paint();
            random = new Random();
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void run() {
            while (isRunning) {
                try {
                    thread.sleep(100);
                    if (libSize != -1) {
                        int index = random.nextInt(libSize);
                        id = index;
                        index = Integer.parseInt(wImg[index]);
                        Canvas c = surfaceHolder.lockCanvas();
                        Drawable d = context.getDrawable(WarriorCardContainer.cards[index]);
                        // d.setBounds(left, top, right, bottom);
                        d.setBounds(0, 0, 96 * 4, 138 * 4);  // img size: 96*138
                        d.draw(c);
                        surfaceHolder.unlockCanvasAndPost(c);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
