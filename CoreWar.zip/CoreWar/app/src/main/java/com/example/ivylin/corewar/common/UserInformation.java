package com.example.ivylin.corewar.common;


import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by IvyLin on 29/02/2016.
 * This class is used for storing common user information
 */
public class UserInformation {
    public static String userName = "Player";
    public static boolean createNewMode = false;
    public static HashMap<Integer, WarriorCardEntity> dataContainer = new HashMap<>();
    public static boolean empty = true;
    public static ArrayList<String> nameContainer = new ArrayList<>(100); // can store 100 warriors
    public static String[] selectedBW = new String[2];
    public static int screenWidth = 0;
    public static int screenHeight = 0;
    public static String battleMode = "";
    public static String warriorLibrary = "";

    /**
     * Reset the frame chosen state
     */
    public static void cleanUpFrame() {

        int size = dataContainer.size();
        Log.d("DEBUG", "It is " + size);
        for (int i = 0; i < size; i++) {
            dataContainer.get(i).view_more = 0;
            dataContainer.get(i).chosenFrame = 0;
        }
    }

    /**
     * Reset the warriors selected for battle
     */
    public static void cleanUpSW() {
        selectedBW[0] = "";
        selectedBW[1] = "";
    }
}
