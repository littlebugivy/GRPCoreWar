package com.example.ivylin.corewar.common;

import android.os.AsyncTask;
import android.os.StrictMode;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Nick on 26/02/16.
 * This class is used for file uploading
 */
public class WarriorUpload extends AsyncTask<File, Void, String> {

    File warriorFile = null;

    /**
     * This method get the warrior file which is created by the user
     */
    public void setWarriorFile(File warriorFile) {
        this.warriorFile = warriorFile;
    }


    public String sendFile() {
        String serverResponse = doInBackground();
        return serverResponse;
    }

    protected String doInBackground(File... urls) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String result = uploadFile(this.warriorFile);

        return result;
    }

    /**
     * Method used to upload files
     * IMPORTANT:
     * The name here should be the the key word which will be used in PHP
     * and the file name should be with ".txt" or other forms' name
     *
     * @param warriorFile
     */
    protected String uploadFile(File warriorFile) {
        Log.d("DEBUG", "Uploading...");
        String result = null;
        String BOUNDARY = "******";
        String PREFIX = "--", LINE_END = "\r\n";
        String CONTENT_TYPE = "multipart/form-data";
        String uNameCookie = "uname="+UserInformation.userName;

        try {
            URL url = new URL("http://192.168.43.34/upload_warrior.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("cookie",uNameCookie);
            conn.setRequestProperty("connection", "keep-alive");
            conn.setRequestProperty("Content-Type", CONTENT_TYPE + ";boundary=" + BOUNDARY);
            if (warriorFile != null) {

                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                StringBuffer sb = new StringBuffer();
                sb.append(PREFIX);
                sb.append(BOUNDARY);
                sb.append(LINE_END);

                sb.append("Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"" + warriorFile.getName() + "\"" + LINE_END);
                sb.append(LINE_END);
                dos.write(sb.toString().getBytes());
                dos.write(sb.toString().getBytes());
                // dos.write(userInfoBytes);
                InputStream is = new FileInputStream(warriorFile);
                byte[] bytes = new byte[1024];
                int len = 0;
                while ((len = is.read(bytes)) != -1) {
                    dos.write(bytes, 0, len);
                }
                is.close();
                dos.write(LINE_END.getBytes());
                byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END).getBytes();
                dos.write(end_data);
                dos.flush();

                InputStream input = conn.getInputStream();
                StringBuffer sb1 = new StringBuffer();
                int ss;
                while ((ss = input.read()) != -1) {
                    sb1.append((char) ss);
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
}




