package com.example.ivylin.corewar.common;

import com.example.ivylin.corewar.R;

/**
 * Created by IvyLin on 18/03/2016.
 * This class sets the default warrior card
 */
public class WarriorCardEntity {
    /**
     * This class give a template for a warrior card, which includes three properties:
     * warrior img, warrior title and the chosen frame*/
        public int image;
        public String title;
        public int chosenFrame;
        public int view_more;

        public WarriorCardEntity(){
            this.chosenFrame = 0;
            this.view_more = 0;
            this.title = "";
            this.image = R.drawable.w1;
        }
        String getTitle(){
            return title;
        }
        int getImage(){ return image;}

}
