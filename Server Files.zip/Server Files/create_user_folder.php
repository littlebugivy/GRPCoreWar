<?php 
include_once("config.php");

if (isset($_POST['userName'])) {

	$user_name = $_POST['userName'];
	//setcookie("uname",$_POST['userName'],time()+1000000);
	
	// Make folder if doesn't exist
	if (!file_exists("./warriorFiles/".$user_name)){
		mkdir("./warriorFiles/".$user_name, 0777, true);
	}
	
	// Check if user has any warriors
	$query = "SELECT * FROM Warriors WHERE uName = '" . $user_name. "'";
	$user_name_test = mysqli_query($con, $query);
	$res = "";
	
	if($user_name_test -> num_rows != 0){
		
		

		while ($result = mysqli_fetch_array($user_name_test, MYSQLI_BOTH)){			
			$res = $res.",".$result["wName"]."#".$result["wImg"];
		} 
	}

	echo $res;
}

else {
	echo "Username not received.";
}

?>


