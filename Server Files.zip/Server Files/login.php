<?php

include_once("config.php"); 

$username = NULL;

if (isset($_POST['uName']) && isset($_POST['uPassword'])) { 

	$username = $_POST['uName'];
	$password = $_POST['uPassword'];

	// check the table for uname & upassword combination
	$query = "SELECT uname, upassword FROM Users ". 
	" WHERE uName = '$username' AND uPassword = '$password'"; 

	$result = mysqli_query($con, $query);

	if ($result->num_rows == 1 ){
		$userName = $username;
		echo "success"; 
		exit; 		
	} else{ 
		echo "Incorrect combination of Uname and Password"; 
		exit;
	} 

} 

?>


