<?php
include_once("config.php");
if(isset($_POST['uName']) && isset($_POST['wName']) && isset($_POST['wImg']) ) { 

	$u_name = $_POST['uName'];
	$w_name = $_POST['wName'];
	$w_img = $_POST['wImg'];
	$query = "INSERT INTO Warriors (uName, wName, wImg) VALUES ('".$u_name."','".$w_name."','".$w_img."')";
	$result = mysqli_query($con, $query);
	echo "Warrior Added";
}
else{
	echo "Warrior Can NOT BE ADDED";
} 
?>