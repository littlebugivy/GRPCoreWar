<?php

	$uName1 = $_POST['uName1'];
	$uName2 = $_POST['uName2'];
	$wName1 = $_POST['wName1'];
	$wName2 = $_POST['wName2'];

	copy("./warriorFiles/".$uName1."/".$wName1, './game/player1');
	copy("./warriorFiles/".$uName2."/".$wName2, './game/player2');

	$output = "";
	exec('./run.sh', $output);

	$file = 'result.txt';

	file_put_contents($file, $output);
?>
