#!/bin/sh
export DYLD_LIBRARY_PATH=""

osascript -e 'do shell script "/Applications/XAMPP/xamppfiles/htdocs/pmars -geometry 800x480 -display 192.168.43.1:0 /Applications/XAMPP/xamppfiles/htdocs/game/player1 /Applications/XAMPP/xamppfiles/htdocs/game/player2"';