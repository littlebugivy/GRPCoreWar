<?php 
	define('HOST', 'localhost'); // db server ip
	define('USER','root'); // db user
	define('PASS', ''); //db password
	define('DB','grp'); // database name

	$con = mysqli_connect(HOST,USER,PASS,DB);

	if (!$con) {
		die("Connection failed: " . mysqli_connect_error());
	}
?>

