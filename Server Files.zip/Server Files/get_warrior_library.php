<?php
include_once("config.php");

$query = "SELECT * FROM Warriors";
$temp = mysqli_query($con, $query);

$res = "";

while ($result = mysqli_fetch_array($temp)) {
	$res = $res.",".$result["uName"]."#".$result["wName"]."#".$result["wImg"];
}

echo $res;

?>