<?PHP 
include_once("config.php");
if(isset($_POST['uName']) && isset($_POST['uPassword']) ) { 

	$username = $_POST['uName'];
	$password = $_POST['uPassword'];

	//test if the username already exists
	$query = "SELECT * FROM Users WHERE uname = '" . $username. "'";
	$user_name_test = mysqli_query($con, $query);

	if($username != "" && $password != ""){
		if( $user_name_test->num_rows == 0){

			$query = "INSERT INTO Users (uName, uPassword) VALUES ('$username','$password')";
			$result = mysqli_query($con, $query);

			if($result != false){
				// success
				echo "success";  
				exit; 		
			} else{ 
				// alert when sql error
				echo "failure with reason".mysql_error();	
			} 
		}
		else{
			// alert when the user already exist
			echo "User Already Exists"; 
		}
	}
	else{
		// alert when the user leave some of the input blank
		echo "Please fill all the blanks";  
	}
} 

?>


