<?php
include_once("config.php");

if(isset($_POST['uName']) && isset($_POST['wName'])) { 
	$u_name = $_POST['uName'];
	$w_name = $_POST['wName'];
	$query = "DELETE FROM Warriors WHERE uName = '".$u_name."' AND wName = '".$w_name."'";
	$result = mysqli_query($con, $query);
	unlink("./warriorFiles/".$u_name."/".$w_name.".red");
	echo "Warrior Deleted";
}

else {
	echo "Warrior Can NOT BE DELETED";
} 
?>